var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/api.ts
var api_exports = {};
__export(api_exports, {
  config: () => config,
  default: () => api_default
});
module.exports = __toCommonJS(api_exports);

// backend/src/repositories/dbRepository.ts
var import_drizzle_orm = require("drizzle-orm");

// db/index.ts
var import_netlify_db = require("drizzle-orm/netlify-db");

// db/schema.ts
var schema_exports = {};
__export(schema_exports, {
  backupAssignments: () => backupAssignments,
  drivers: () => drivers,
  scheduleShifts: () => scheduleShifts
});
var import_pg_core = require("drizzle-orm/pg-core");
var drivers = (0, import_pg_core.pgTable)("drivers", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  name: (0, import_pg_core.text)("name").notNull(),
  phone: (0, import_pg_core.text)("phone").notNull(),
  routeNumber: (0, import_pg_core.text)("route_number").notNull(),
  contractType: (0, import_pg_core.text)("contract_type").notNull(),
  createdAt: (0, import_pg_core.timestamp)("created_at", { withTimezone: true }).notNull(),
  isDeleted: (0, import_pg_core.boolean)("is_deleted").notNull().default(false)
});
var scheduleShifts = (0, import_pg_core.pgTable)("schedule_shifts", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  driverId: (0, import_pg_core.text)("driver_id").notNull().references(() => drivers.id),
  date: (0, import_pg_core.text)("date").notNull(),
  status: (0, import_pg_core.text)("status").notNull()
});
var backupAssignments = (0, import_pg_core.pgTable)("backup_assignments", {
  id: (0, import_pg_core.text)("id").primaryKey(),
  date: (0, import_pg_core.text)("date").notNull(),
  routeNumber: (0, import_pg_core.text)("route_number").notNull(),
  originalDriverId: (0, import_pg_core.text)("original_driver_id").notNull(),
  originalDriverName: (0, import_pg_core.text)("original_driver_name").notNull(),
  backupDriverId: (0, import_pg_core.text)("backup_driver_id").notNull(),
  backupDriverName: (0, import_pg_core.text)("backup_driver_name").notNull(),
  note: (0, import_pg_core.text)("note"),
  createdAt: (0, import_pg_core.timestamp)("created_at", { withTimezone: true }).notNull()
});

// db/index.ts
var db = (0, import_netlify_db.drizzle)({ schema: schema_exports });

// backend/src/repositories/dbRepository.ts
function toDriver(row) {
  return {
    id: row.id,
    name: row.name,
    phone: row.phone,
    routeNumber: row.routeNumber,
    contractType: row.contractType,
    createdAt: row.createdAt.toISOString(),
    isDeleted: row.isDeleted
  };
}
function toShift(row) {
  return {
    id: row.id,
    driverId: row.driverId,
    date: row.date,
    status: row.status
  };
}
function toBackup(row) {
  return {
    id: row.id,
    date: row.date,
    routeNumber: row.routeNumber,
    originalDriverId: row.originalDriverId,
    originalDriverName: row.originalDriverName,
    backupDriverId: row.backupDriverId,
    backupDriverName: row.backupDriverName,
    note: row.note ?? void 0,
    createdAt: row.createdAt.toISOString()
  };
}
var DriverRepository = class {
  async findAll(includeDeleted = false) {
    const rows = await db.select().from(drivers);
    const filtered = includeDeleted ? rows : rows.filter((d) => !d.isDeleted);
    return filtered.map(toDriver);
  }
  async findById(id) {
    const rows = await db.select().from(drivers).where((0, import_drizzle_orm.eq)(drivers.id, id)).limit(1);
    const row = rows[0];
    if (!row || row.isDeleted) return void 0;
    return toDriver(row);
  }
  async create(dto) {
    const newDriver = {
      id: `drv-${Date.now()}`,
      name: dto.name,
      phone: dto.phone,
      routeNumber: dto.routeNumber,
      contractType: dto.contractType,
      createdAt: /* @__PURE__ */ new Date(),
      isDeleted: false
    };
    const [row] = await db.insert(drivers).values(newDriver).returning();
    return toDriver(row);
  }
  async update(id, dto) {
    const existing = await this.findById(id);
    if (!existing) return null;
    const [row] = await db.update(drivers).set({
      name: dto.name ?? existing.name,
      phone: dto.phone ?? existing.phone,
      routeNumber: dto.routeNumber ?? existing.routeNumber,
      contractType: dto.contractType ?? existing.contractType
    }).where((0, import_drizzle_orm.eq)(drivers.id, id)).returning();
    return row ? toDriver(row) : null;
  }
  async softDelete(id) {
    const existing = await this.findById(id);
    if (!existing) return false;
    await db.update(drivers).set({ isDeleted: true }).where((0, import_drizzle_orm.eq)(drivers.id, id));
    return true;
  }
};
var ScheduleRepository = class {
  async findShifts(startDate, endDate, driverId) {
    const conditions = [];
    if (startDate) conditions.push((0, import_drizzle_orm.gte)(scheduleShifts.date, startDate));
    if (endDate) conditions.push((0, import_drizzle_orm.lte)(scheduleShifts.date, endDate));
    if (driverId) conditions.push((0, import_drizzle_orm.eq)(scheduleShifts.driverId, driverId));
    const rows = conditions.length > 0 ? await db.select().from(scheduleShifts).where((0, import_drizzle_orm.and)(...conditions)) : await db.select().from(scheduleShifts);
    return rows.map(toShift);
  }
  async findShift(driverId, date) {
    const rows = await db.select().from(scheduleShifts).where((0, import_drizzle_orm.and)((0, import_drizzle_orm.eq)(scheduleShifts.driverId, driverId), (0, import_drizzle_orm.eq)(scheduleShifts.date, date))).limit(1);
    return rows[0] ? toShift(rows[0]) : void 0;
  }
  async upsertShift(driverId, date, status) {
    const existing = await this.findShift(driverId, date);
    if (existing) {
      const [row2] = await db.update(scheduleShifts).set({ status }).where((0, import_drizzle_orm.eq)(scheduleShifts.id, existing.id)).returning();
      return toShift(row2);
    }
    const newShift = {
      id: `shift-${driverId}-${date}`,
      driverId,
      date,
      status
    };
    const [row] = await db.insert(scheduleShifts).values(newShift).returning();
    return toShift(row);
  }
  async getOffDays(startDate, endDate) {
    const conditions = [(0, import_drizzle_orm.eq)(scheduleShifts.status, "\uD734\uBB34")];
    if (startDate) conditions.push((0, import_drizzle_orm.gte)(scheduleShifts.date, startDate));
    if (endDate) conditions.push((0, import_drizzle_orm.lte)(scheduleShifts.date, endDate));
    const rows = await db.select().from(scheduleShifts).where((0, import_drizzle_orm.and)(...conditions));
    return rows.map(toShift);
  }
};
var BackupRepository = class {
  async findAll() {
    const rows = await db.select().from(backupAssignments);
    return rows.map(toBackup);
  }
  async findByDateAndRoute(date, routeNumber) {
    const rows = await db.select().from(backupAssignments).where((0, import_drizzle_orm.and)((0, import_drizzle_orm.eq)(backupAssignments.date, date), (0, import_drizzle_orm.eq)(backupAssignments.routeNumber, routeNumber))).limit(1);
    return rows[0] ? toBackup(rows[0]) : void 0;
  }
  async findByDate(date) {
    const rows = await db.select().from(backupAssignments).where((0, import_drizzle_orm.eq)(backupAssignments.date, date));
    return rows.map(toBackup);
  }
  async assignBackup(dto) {
    const originalDriver = await driverRepository.findById(dto.originalDriverId);
    const backupDriver = await driverRepository.findById(dto.backupDriverId);
    if (!originalDriver || !backupDriver) return null;
    await db.delete(backupAssignments).where(
      (0, import_drizzle_orm.and)(
        (0, import_drizzle_orm.eq)(backupAssignments.date, dto.date),
        (0, import_drizzle_orm.eq)(backupAssignments.routeNumber, dto.routeNumber)
      )
    );
    const newAssignment = {
      id: `bak-${Date.now()}`,
      date: dto.date,
      routeNumber: dto.routeNumber,
      originalDriverId: originalDriver.id,
      originalDriverName: originalDriver.name,
      backupDriverId: backupDriver.id,
      backupDriverName: backupDriver.name,
      note: dto.note || "\uC218\uB3D9 \uC9C0\uC815 \uC644\uB8CC",
      createdAt: /* @__PURE__ */ new Date()
    };
    const [row] = await db.insert(backupAssignments).values(newAssignment).returning();
    return toBackup(row);
  }
  async removeAssignment(date, routeNumber) {
    const existing = await this.findByDateAndRoute(date, routeNumber);
    if (!existing) return false;
    await db.delete(backupAssignments).where(
      (0, import_drizzle_orm.and)(
        (0, import_drizzle_orm.eq)(backupAssignments.date, date),
        (0, import_drizzle_orm.eq)(backupAssignments.routeNumber, routeNumber)
      )
    );
    return true;
  }
};
var driverRepository = new DriverRepository();
var scheduleRepository = new ScheduleRepository();
var backupRepository = new BackupRepository();

// backend/src/services/index.ts
var DriverService = class {
  async getAllDrivers(search, route, contractType) {
    let drivers2 = await driverRepository.findAll();
    if (search && search.trim() !== "") {
      const q = search.trim().toLowerCase();
      drivers2 = drivers2.filter(
        (d) => d.name.toLowerCase().includes(q) || d.routeNumber.toLowerCase().includes(q) || d.phone.includes(q)
      );
    }
    if (route && route.trim() !== "") {
      drivers2 = drivers2.filter((d) => d.routeNumber === route.trim());
    }
    if (contractType && contractType.trim() !== "") {
      drivers2 = drivers2.filter((d) => d.contractType === contractType.trim());
    }
    return drivers2;
  }
  async getDriverById(id) {
    return await driverRepository.findById(id) || null;
  }
  async createDriver(dto) {
    if (!dto.name || !dto.phone || !dto.routeNumber || !dto.contractType) {
      throw new Error("\uD544\uC218 \uC785\uB825\uAC12\uC774 \uB204\uB77D\uB418\uC5C8\uC2B5\uB2C8\uB2E4 (\uAE30\uC0AC\uBA85, \uC5F0\uB77D\uCC98, \uB77C\uC6B0\uD2B8\uBC88\uD638, \uACC4\uC57D\uD615\uD0DC)");
    }
    return driverRepository.create(dto);
  }
  async updateDriver(id, dto) {
    const updated = await driverRepository.update(id, dto);
    if (!updated) {
      throw new Error("\uD574\uB2F9 \uAE30\uC0AC\uB97C \uCC3E\uC744 \uC218 \uC5C6\uAC70\uB098 \uC774\uBBF8 \uC0AD\uC81C\uB418\uC5C8\uC2B5\uB2C8\uB2E4");
    }
    return updated;
  }
  async deleteDriver(id) {
    const success = await driverRepository.softDelete(id);
    if (!success) {
      throw new Error("\uAE30\uC0AC \uC0AD\uC81C\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4");
    }
    return true;
  }
};
var ScheduleService = class {
  async getScheduleGrid(startDate, endDate) {
    const drivers2 = await driverRepository.findAll();
    const shifts = await scheduleRepository.findShifts(startDate, endDate);
    const backupAssignments2 = await backupRepository.findAll();
    const backupMap = /* @__PURE__ */ new Map();
    backupAssignments2.forEach((b) => {
      backupMap.set(`${b.date}_${b.originalDriverId}`, b);
    });
    return drivers2.map((driver) => {
      const driverShifts = shifts.filter((s) => s.driverId === driver.id);
      const shiftMap = {};
      driverShifts.forEach((shift) => {
        const backupInfo = backupMap.get(`${shift.date}_${driver.id}`);
        shiftMap[shift.date] = {
          status: shift.status,
          backupAssigned: !!backupInfo,
          backupDriverId: backupInfo?.backupDriverId,
          backupDriverName: backupInfo?.backupDriverName
        };
      });
      return {
        driverId: driver.id,
        driverName: driver.name,
        routeNumber: driver.routeNumber,
        contractType: driver.contractType,
        shifts: shiftMap
      };
    });
  }
  async updateCellStatus(driverId, date, status) {
    const driver = await driverRepository.findById(driverId);
    if (!driver) throw new Error("\uAE30\uC0AC \uC815\uBCF4\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4.");
    const shift = await scheduleRepository.upsertShift(driverId, date, status);
    if (status !== "\uD734\uBB34") {
      await backupRepository.removeAssignment(date, driver.routeNumber);
    }
    return shift;
  }
  async getOffDaySummary(startDate, endDate) {
    const offDayShifts = await scheduleRepository.getOffDays(startDate, endDate);
    const drivers2 = await driverRepository.findAll();
    const backupAssignments2 = await backupRepository.findAll();
    const driverMap = new Map(drivers2.map((d) => [d.id, d]));
    const backupMap = new Map(backupAssignments2.map((b) => [`${b.date}_${b.originalDriverId}`, b]));
    return offDayShifts.map((shift) => {
      const driver = driverMap.get(shift.driverId);
      const backup = backupMap.get(`${shift.date}_${shift.driverId}`);
      return {
        id: shift.id,
        driverId: shift.driverId,
        driverName: driver ? driver.name : "\uBBF8\uC0C1",
        routeNumber: driver ? driver.routeNumber : "-",
        date: shift.date,
        backupAssigned: !!backup,
        backupDriverId: backup?.backupDriverId,
        backupDriverName: backup?.backupDriverName
      };
    });
  }
};
var BackupService = class {
  async getAllAssignments() {
    return backupRepository.findAll();
  }
  async getAvailableBackupDrivers(date) {
    const drivers2 = await driverRepository.findAll();
    const shiftsOnDate = await scheduleRepository.findShifts(date, date);
    const offDriverIds = new Set(
      shiftsOnDate.filter((s) => s.status === "\uD734\uBB34").map((s) => s.driverId)
    );
    return drivers2.filter((d) => !offDriverIds.has(d.id));
  }
  async assignBackup(dto) {
    if (!dto.date || !dto.routeNumber || !dto.originalDriverId || !dto.backupDriverId) {
      throw new Error("\uD544\uC218 \uC815\uBCF4\uAC00 \uB204\uB77D\uB418\uC5C8\uC2B5\uB2C8\uB2E4 (\uB0A0\uC9DC, \uB77C\uC6B0\uD2B8, \uAE30\uC874\uAE30\uC0AC, \uBC31\uC5C5\uAE30\uC0AC)");
    }
    const assignment = await backupRepository.assignBackup(dto);
    if (!assignment) {
      throw new Error("\uB300\uCC28 \uC9C0\uC815\uC5D0 \uC2E4\uD328\uD588\uC2B5\uB2C8\uB2E4.");
    }
    return assignment;
  }
};
var driverService = new DriverService();
var scheduleService = new ScheduleService();
var backupService = new BackupService();

// backend/src/api/handler.ts
var CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
  "Content-Type": "application/json"
};
function jsonResponse(body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: CORS_HEADERS });
}
function errorResponse(message, status) {
  return jsonResponse({ success: false, message }, status);
}
async function parseBody(req) {
  const text2 = await req.text();
  if (!text2) return {};
  return JSON.parse(text2);
}
async function handleApiRequest(req) {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }
  const url = new URL(req.url);
  const path = url.pathname.replace(/\/$/, "") || "/";
  const method = req.method;
  try {
    if (path === "/api/health" && method === "GET") {
      return jsonResponse({
        success: true,
        data: { status: "ok", system: "Coupang Fleet Sync API", timestamp: (/* @__PURE__ */ new Date()).toISOString() }
      });
    }
    if (path === "/api/drivers" && method === "GET") {
      const drivers2 = await driverService.getAllDrivers(
        url.searchParams.get("search") ?? void 0,
        url.searchParams.get("route") ?? void 0,
        url.searchParams.get("contractType") ?? void 0
      );
      return jsonResponse({ success: true, data: drivers2 });
    }
    const driverMatch = path.match(/^\/api\/drivers\/([^/]+)$/);
    if (driverMatch) {
      const id = driverMatch[1];
      if (method === "GET") {
        const driver = await driverService.getDriverById(id);
        if (!driver) return errorResponse("\uAE30\uC0AC\uB97C \uCC3E\uC744 \uC218 \uC5C6\uC2B5\uB2C8\uB2E4", 404);
        return jsonResponse({ success: true, data: driver });
      }
      if (method === "PUT") {
        const body = await parseBody(req);
        const updated = await driverService.updateDriver(id, body);
        return jsonResponse({ success: true, data: updated, message: "\uAE30\uC0AC \uC815\uBCF4\uAC00 \uC218\uC815\uB418\uC5C8\uC2B5\uB2C8\uB2E4" });
      }
      if (method === "DELETE") {
        await driverService.deleteDriver(id);
        return jsonResponse({ success: true, message: "\uAE30\uC0AC \uC815\uBCF4\uAC00 \uC18C\uD504\uD2B8 \uC0AD\uC81C \uCC98\uB9AC\uB418\uC5C8\uC2B5\uB2C8\uB2E4" });
      }
    }
    if (path === "/api/drivers" && method === "POST") {
      const body = await parseBody(req);
      const newDriver = await driverService.createDriver(body);
      return jsonResponse({ success: true, data: newDriver, message: "\uAE30\uC0AC\uAC00 \uC2E0\uADDC \uB4F1\uB85D\uB418\uC5C8\uC2B5\uB2C8\uB2E4" }, 201);
    }
    if (path === "/api/schedules/grid" && method === "GET") {
      const startDate = url.searchParams.get("startDate");
      const endDate = url.searchParams.get("endDate");
      if (!startDate || !endDate) {
        return errorResponse("startDate\uC640 endDate \uC870\uD68C\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4", 400);
      }
      const grid = await scheduleService.getScheduleGrid(startDate, endDate);
      return jsonResponse({ success: true, data: grid });
    }
    if (path === "/api/schedules/cell" && method === "PUT") {
      const body = await parseBody(req);
      if (!body.driverId || !body.date || !body.status) {
        return errorResponse("driverId, date, status \uC815\uBCF4\uAC00 \uD544\uC218\uC785\uB2C8\uB2E4", 400);
      }
      const shift = await scheduleService.updateCellStatus(body.driverId, body.date, body.status);
      return jsonResponse({ success: true, data: shift, message: "\uADFC\uBB34 \uC0C1\uD0DC\uAC00 \uC218\uC815\uB418\uC5C8\uC2B5\uB2C8\uB2E4" });
    }
    if (path === "/api/schedules/offdays" && method === "GET") {
      const offDays = await scheduleService.getOffDaySummary(
        url.searchParams.get("startDate") ?? void 0,
        url.searchParams.get("endDate") ?? void 0
      );
      return jsonResponse({ success: true, data: offDays });
    }
    if (path === "/api/backups" && method === "GET") {
      const assignments = await backupService.getAllAssignments();
      return jsonResponse({ success: true, data: assignments });
    }
    if (path === "/api/backups/candidates" && method === "GET") {
      const date = url.searchParams.get("date");
      if (!date) return errorResponse("\uC870\uD68C \uAE30\uC900 \uB0A0\uC9DC(date)\uAC00 \uD544\uC694\uD569\uB2C8\uB2E4", 400);
      const candidates = await backupService.getAvailableBackupDrivers(date);
      return jsonResponse({ success: true, data: candidates });
    }
    if (path === "/api/backups/assign" && method === "POST") {
      const body = await parseBody(req);
      const assignment = await backupService.assignBackup(body);
      return jsonResponse({ success: true, data: assignment, message: "\uB300\uCC28 \uAE30\uC0AC\uAC00 \uC9C0\uC815\uB418\uC5C8\uC2B5\uB2C8\uB2E4" }, 201);
    }
    return errorResponse("Not Found", 404);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Internal Server Error";
    const status = message.includes("\uCC3E\uC744") || message.includes("\uC0AD\uC81C") ? 400 : 500;
    return errorResponse(message, status);
  }
}

// netlify/functions/api.ts
var api_default = async (req) => handleApiRequest(req);
var config = {
  path: "/api/*"
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  config
});
